
<html>
<head>
<link rel="stylesheet" type="text/css" href="1.css">
</head>
<body>

<div class="p">
  <h3>Census form</h3>
  <?php
$name=$_REQUEST['name'];
$gender=$_REQUEST['gender'];
$date=$_REQUEST['date'];
$hname=$_REQUEST['hname'];
$fname=$_REQUEST['fname'];
$mname=$_REQUEST['mname'];
$status=$_REQUEST['status'];
$edu=$_REQUEST['education'];
$spause= $_REQUEST['spouse'];
$ch= $_REQUEST['children'];
$boy= $_REQUEST['boy'];
$girl= $_REQUEST['girl'];

echo "Census form<br><br><br>";

echo"Name of the person:&nbsp&nbsp&nbsp&nbsp&nbsp$name<br><br>";
echo "Gender:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$gender<br><br>";
echo "Date of Birth:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$date<br><br>";
echo "Head of the family:&nbsp&nbsp&nbsp&nbsp&nbsp$hname<br><br>";
echo "Name of Father:&nbsp&nbsp&nbsp&nbsp&nbsp$fname<br><br>";
echo "Name of mother:&nbsp&nbsp&nbsp&nbsp&nbsp$mname<br><br>";
echo "Current marital status:&nbsp&nbsp&nbsp&nbsp&nbsp$status<br><br>";
echo "Highest educational level attained:&nbsp&nbsp&nbsp$edu<br><br>";
echo "Name of spouse:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$spause<br><br>";
echo "Number of children:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$ch<br><br>";
echo "Name of boy:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$boy<br><br>";
echo "Name of girl:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp$boy<br><br>";
 ?>
</div>

<body>
<html>
